﻿// Copyright (c) 2017 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

#pragma warning disable 0649

using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Rewired.Integration.UniversalFightingEngine {

    public class RewiredUFEInputManager : MonoBehaviour, RewiredInputController.IInputSource, RewiredInputController.ITouchInputUI, RewiredInputController.IInputConfiguration {

        private const string className = "RewiredUFEInputManager";

        #region Variables

        [Header("Control Mapper")]
        [Tooltip("Link Control Mapper here if you're using it.")]
        [SerializeField]
        private Rewired.UI.ControlMapper.ControlMapper _controlMapper;

        [Tooltip("Actions to disable while Control Mapper is open.")]
        [SerializeField]
        private string[] _actionsToDisableIfControlMapperOpen = new string[] {
            "Start"
        };

        [Header("Touch Controls")]
        [Tooltip("Link the touch controls GameObject here. This GameObject will be enabled and disabled when the touch UI is shown / hidden.")]
        [SerializeField]
        private GameObject _touchControls;

        [Tooltip("Should touch controls be hidden when a joystick is connected?")]
        [SerializeField]
        private bool _hideTouchControlsWhenJoysticksConnected = true;

        [Tooltip("Show touch controls on the following platforms.")]
        [SerializeField]
        [Rewired.Utils.Attributes.BitmaskToggle(typeof(PlatformFlags))]
        private PlatformFlags _showTouchControlsOn = PlatformFlags.Android | PlatformFlags.IOS;

        private bool _initialized;
        private bool _autoTouchControlUI_isActive;
        private bool _touchControlsActiveExternal;
        private Action _inputConfigurationUIClosedCallback;
        private bool _eventSystemSendNavigationEventsOrig;

        #endregion

        #region RewiredInputController.IInputSource Implementation

        public float GetAxis(int playerId, string name) {
            if(!_initialized || !isEnabled) return 0f;
            return ReInput.players.GetPlayer(playerId).GetAxis(name);
        }

        public float GetAxisRaw(int playerId, string name) {
            if(!_initialized || !isEnabled) return 0f;
            return ReInput.players.GetPlayer(playerId).GetAxisRaw(name);
        }

        public bool GetButton(int playerId, string name) {
            if(!_initialized || !isEnabled) return false;
            return ReInput.players.GetPlayer(playerId).GetButton(name);
        }

        #endregion

        #region RewiredInputController.ITouchInputUI Implementation

        public bool showTouchControls {
            get {
                return _initialized &&
                    isEnabled &&
                    supportsTouchControls &&
                    _touchControlsActiveExternal &&
                    (_hideTouchControlsWhenJoysticksConnected ? _autoTouchControlUI_isActive : true);
            }
            set {
                _touchControlsActiveExternal = value;
                if(value && (!_initialized || !isEnabled || !supportsTouchControls)) return;
                EvaluateTouchControlsActive();
            }
        }

        #endregion

        #region RewiredInputController.IInputConfiguration Implementation

        public bool showInputConfigurationUI {
            get {
                if(_controlMapper == null) return false;
                return _controlMapper.isOpen;
            }
            set {
                if(_controlMapper == null) return;
                if(_controlMapper.isOpen == value) return;
                if(value) {
                    _controlMapper.Open();
                } else {
                    _controlMapper.Close(true);
                }
            }
        }

        public void ShowInputConfigurationUI(Action closedCallback) {
            if(_controlMapper == null) return;
            _inputConfigurationUIClosedCallback = closedCallback;
            showInputConfigurationUI = true;
        }

        #endregion

        #region Monobehaviour Callbacks

        private void Awake() {
            if(!ReInput.isReady) {
                Debug.LogError(className + ": Rewired is not initialized. You must have an active Rewired Input Manager in the scene.");
                return;
            }

            // Show/hide the touch UI initially
            bool showTouchControls = supportsTouchControls;
            _touchControlsActiveExternal = showTouchControls;
            SetTouchControlsActive(showTouchControls);

            if(_hideTouchControlsWhenJoysticksConnected) {
                _autoTouchControlUI_isActive = showTouchControls;
                CheckHideTouchControlsWhenJoystickConnected();
            }

            _initialized = true;
        }

        private void Start() {
            // Store the original EventSystem navigation events setting so it can be restored after changing.
            // This is done because UFE cannot work with navigation events enabled because their UFEScreen system
            // has its own navigation system and enabling the EventSystem's also will cause double navigation.
            // Control Mapper requires it, so only enable it when Control Mapper is open.
            if(EventSystem.current != null) _eventSystemSendNavigationEventsOrig = EventSystem.current.sendNavigationEvents;
        }

        private void OnEnable() {
            // Set up static references in UFE
            RewiredInputController.inputSource = this;
            if(_touchControls != null) RewiredInputController.touchInputUI = this;
            if(_controlMapper != null) RewiredInputController.inputConfiguration = this;

            // Subscribe to events
            ReInput.ControllerConnectedEvent += OnControllerConnected;
            ReInput.ControllerDisconnectedEvent += OnControllerDisconnected;
            if(_controlMapper != null) {
                _controlMapper.ScreenOpenedEvent += OnControlMapperOpened;
                _controlMapper.ScreenClosedEvent += OnControlMapperClosed;
            }
        }

        private void OnDisable() {
            // Remove static references in UFE
            if(RewiredInputController.inputSource == this as RewiredInputController.IInputSource) {
                RewiredInputController.inputSource = null;
            }
            if(RewiredInputController.touchInputUI == this as RewiredInputController.ITouchInputUI) {
                RewiredInputController.touchInputUI = null;
            }
            if(RewiredInputController.inputConfiguration == this as RewiredInputController.IInputConfiguration) {
                RewiredInputController.inputConfiguration = null;
            }

            // Unsubscribe from events
            ReInput.ControllerConnectedEvent -= OnControllerConnected;
            ReInput.ControllerDisconnectedEvent -= OnControllerDisconnected;
            if(_controlMapper != null) {
                _controlMapper.ScreenOpenedEvent -= OnControlMapperOpened;
                _controlMapper.ScreenClosedEvent -= OnControlMapperClosed;
            }
        }

        #endregion

        #region Private Properties

        private bool supportsTouchControls {
            get {
                if(_showTouchControlsOn == PlatformFlags.None) return false;
                if(_touchControls == null) return false;

                PlatformFlags p = _showTouchControlsOn;
                if(Rewired.Utils.UnityTools.isEditor && (p & PlatformFlags.Editor) != 0) return true;

                if(!UnityEngine.Input.touchSupported) return false;

                var platform = Rewired.Utils.UnityTools.platform;
                if(platform == Rewired.Platforms.Platform.Windows) return (p & PlatformFlags.Windows) != 0;
                if(platform == Rewired.Platforms.Platform.OSX) return (p & PlatformFlags.OSX) != 0;
                if(platform == Rewired.Platforms.Platform.Linux) return (p & PlatformFlags.Linux) != 0;
                if(platform == Rewired.Platforms.Platform.iOS) return (p & PlatformFlags.IOS) != 0;
                if(platform == Rewired.Platforms.Platform.tvOS) return (p & PlatformFlags.TVOS) != 0;
                if(platform == Rewired.Platforms.Platform.Android) return (p & PlatformFlags.Android) != 0;
                if(platform == Rewired.Platforms.Platform.AmazonFireTV) return (p & PlatformFlags.AmazonFireTV) != 0;
                if(platform == Rewired.Platforms.Platform.RazerForgeTV) return (p & PlatformFlags.RazerForgeTV) != 0;
                if(platform == Rewired.Platforms.Platform.Windows81Store || platform == Rewired.Platforms.Platform.WindowsAppStore) return (p & PlatformFlags.Windows8Store) != 0;
                if(platform == Rewired.Platforms.Platform.WindowsUWP) return (p & PlatformFlags.WindowsUWP10) != 0;
                if(platform == Rewired.Platforms.Platform.WebGL) return (p & PlatformFlags.WebGL) != 0;
                if(platform == Rewired.Platforms.Platform.PS4) return (p & PlatformFlags.PS4) != 0;
                if(platform == Rewired.Platforms.Platform.PSMobile || platform == Rewired.Platforms.Platform.PSVita) return (p & PlatformFlags.PSVita) != 0;
                if(platform == Rewired.Platforms.Platform.Xbox360) return (p & PlatformFlags.Xbox360) != 0;
                if(platform == Rewired.Platforms.Platform.XboxOne) return (p & PlatformFlags.XboxOne) != 0;
                if(platform == Rewired.Platforms.Platform.SamsungTV) return (p & PlatformFlags.SamsungTV) != 0;
                if(platform == Rewired.Platforms.Platform.WiiU) return (p & PlatformFlags.WiiU) != 0;
                if(platform == Rewired.Platforms.Platform.N3DS) return (p & PlatformFlags.Nintendo3DS) != 0;
                if(platform == Rewired.Platforms.Platform.Switch) return (p & PlatformFlags.Switch) != 0;
                return (p & PlatformFlags.Unknown) != 0;
            }
        }

        private bool isEnabled { get { return this.isActiveAndEnabled; } }

        #endregion

        #region Private Methods

        private void CheckHideTouchControlsWhenJoystickConnected() {
            if(!_hideTouchControlsWhenJoysticksConnected) return;

            if(_autoTouchControlUI_isActive) {
                // Disable touch controls if a joystick is connected
                if(Rewired.ReInput.controllers.joystickCount > 0) {
                    _autoTouchControlUI_isActive = false;
                }
            } else {
                // Enable touch controls if no joysticks are connected
                if(Rewired.ReInput.controllers.joystickCount == 0) {
                    _autoTouchControlUI_isActive = true;
                }
            }

            EvaluateTouchControlsActive();
        }

        private void EvaluateTouchControlsActive() {
            // Set the active state on the touch controls based on the external state and the auto state
            // Only set active if both external and internal are active
            SetTouchControlsActive(showTouchControls);
        }

        private void SetTouchControlsActive(bool active) {
            if(_touchControls == null) return;
            // Make sure Rewired's always the active event system
            if (_eventSystem != null) EventSystem.current = _eventSystem;
            if(_touchControls.activeInHierarchy == active) return;
            _touchControls.SetActive(active);
        }

        // Event Handlers

        private void OnControllerConnected(Rewired.ControllerStatusChangedEventArgs args) {
            if(args.controllerType != ControllerType.Joystick) return;
            CheckHideTouchControlsWhenJoystickConnected();
        }

        private void OnControllerDisconnected(Rewired.ControllerStatusChangedEventArgs args) {
            if(args.controllerType != ControllerType.Joystick) return;
            CheckHideTouchControlsWhenJoystickConnected();
        }

        private void OnControlMapperOpened() {
            // Enable navigation events for Control Mapper
            if(EventSystem.current != null) EventSystem.current.sendNavigationEvents = true;

            // Disable Start action to prevent game from unpausing behind Control Mapper
            for (int i = 0; i < ReInput.players.playerCount; i++) {
                Player player = ReInput.players.Players[i];
                foreach (var map in player.controllers.maps.GetAllMaps()) {
                    foreach (var a in _actionsToDisableIfControlMapperOpen) {
                        map.ForEachElementMapMatch(x => x.actionId == ReInput.mapping.GetAction(a).id, x => x.enabled = false);
                    }
                }
            }
        }

        private void OnControlMapperClosed() {
            // Restore navigation events settings to original after closing
            if(EventSystem.current != null) EventSystem.current.sendNavigationEvents = _eventSystemSendNavigationEventsOrig;

            // Invoke callback
            if(_inputConfigurationUIClosedCallback != null) {
                try {
                    _inputConfigurationUIClosedCallback();
                } catch(Exception ex) {
                    Debug.LogError(className + ": An exception occurred while invoking callback.\n" + ex);
                } finally {
                    _inputConfigurationUIClosedCallback = null; // clear the callback each time
                }
            }

            // Re-enable Start action
            for (int i = 0; i < ReInput.players.playerCount; i++) {
                Player player = ReInput.players.Players[i];
                foreach (var map in player.controllers.maps.GetAllMaps()) {
                    foreach (var a in _actionsToDisableIfControlMapperOpen) {
                        map.ForEachElementMapMatch(x => x.actionId == ReInput.mapping.GetAction(a).id, x => x.enabled = true);
                    }
                }
            }
            ReInput.userDataStore.Save(); // save data again so bindings are saved enabled
        }

        #endregion

        #region Enums

        private enum PlatformFlags {
            None = 0,
            Editor = 1,
            Windows = 1 << 1,
            OSX = 1 << 2,
            Linux = 1 << 3,
            IOS = 1 << 4,
            TVOS = 1 << 5,
            Android = 1 << 6,
            Windows8Store = 1 << 7,
            WindowsUWP10 = 1 << 8,
            WebGL = 1 << 9,
            PS4 = 1 << 10,
            PSVita = 1 << 11,
            Xbox360 = 1 << 12,
            XboxOne = 1 << 13,
            SamsungTV = 1 << 14,
            WiiU = 1 << 15,
            Nintendo3DS = 1 << 16,
            Switch = 1 << 17,
            AmazonFireTV = 1 << 18,
            RazerForgeTV = 1 << 19,
            Unknown = 1 << 31
        }

        #endregion
    }
}