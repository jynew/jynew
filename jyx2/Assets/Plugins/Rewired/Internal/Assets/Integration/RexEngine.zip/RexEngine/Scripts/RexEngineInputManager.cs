﻿// Copyright (c) 2017 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

#pragma warning disable 0219
#pragma warning disable 0618
#pragma warning disable 0649
#pragma warning disable 0414
#pragma warning disable 0162

namespace Rewired.Integration.RexEngine {
    using UnityEngine;
    using System.Collections.Generic;

    [RequireComponent(typeof(InputManager))]
    public sealed class RexEngineInputManager : global::RexEngine.InputManager, global::RexEngine.ITouchInputManager {

        #region Consts

        private const string scriptMessagePrefix = "Rewired Rex Engine Input Manager: ";
        private const string rewiredNotInitializedError = scriptMessagePrefix + "Rewired is not initialized. You must have an enabled Rewired Input Manager in the scene.";

        #endregion

        [SerializeField]
        [Tooltip("Maps Rex Engine input actions to Rewired Actions.")]
        private List<ActionMapping> _actionMappings = new List<ActionMapping>();

        [Tooltip("Link the touch controls GameObject here. This GameObject will be enabled and disabled when the touch UI is shown / hidden.")]
        [SerializeField]
        private GameObject _touchControls;

        [Tooltip("Should touch controls be hidden when a joystick is connected?")]
        [SerializeField]
        private bool _hideTouchControlsWhenJoysticksConnected = true;

        [Tooltip("Show touch controls on the following platforms.")]
        [SerializeField]
        [Utils.Attributes.BitmaskToggle(typeof(PlatformFlags))]
        private PlatformFlags _showTouchControlsOn = PlatformFlags.Android | PlatformFlags.IOS;

        private Dictionary<int, ActionMapping> _actionMappingsDictionary = new Dictionary<int, ActionMapping>();
        private bool _initialized;
        private bool _autoTouchControlUI_isActive;
        private bool _touchControlsActiveExternal;

        /// <summary>
        /// Should touch controls be shown?
        /// </summary>
        public bool showTouchControls {
            get {
                return _initialized &&
                    Enabled &&
                    supportsTouchControls &&
                    _touchControlsActiveExternal &&
                    (_hideTouchControlsWhenJoysticksConnected ? _autoTouchControlUI_isActive : true);
            }
            set {
                _touchControlsActiveExternal = value;
                if(value && (!_initialized || !Enabled || !supportsTouchControls)) return;
                EvaluateTouchControlsActive();
            }
        }

        /// <summary>
        /// Maps Rex Engine input actions to Rewired Actions.
        /// </summary>
        public List<ActionMapping> actionMappings {
            get { return _actionMappings ?? (_actionMappings = new List<ActionMapping>()); }
            set {
                _actionMappings = value;
                if (Rewired.ReInput.isReady) InitializeActionCache();
            }
        }

        private bool supportsTouchControls {
            get {
                if(_showTouchControlsOn == PlatformFlags.None) return false;
                if(_touchControls == null) return false;

                PlatformFlags p = _showTouchControlsOn;
                if(Rewired.Utils.UnityTools.isEditor && (p & PlatformFlags.Editor) != 0) return true;

                if(!UnityEngine.Input.touchSupported) return false;

                var platform = Utils.UnityTools.platform;
                if(platform == Platforms.Platform.Windows) return (p & PlatformFlags.Windows) != 0;
                if(platform == Platforms.Platform.OSX) return (p & PlatformFlags.OSX) != 0;
                if(platform == Platforms.Platform.Linux) return (p & PlatformFlags.Linux) != 0;
                if(platform == Platforms.Platform.iOS) return (p & PlatformFlags.IOS) != 0;
                if(platform == Platforms.Platform.tvOS) return (p & PlatformFlags.TVOS) != 0;
                if(platform == Platforms.Platform.Android) return (p & PlatformFlags.Android) != 0;
                if(platform == Platforms.Platform.AmazonFireTV) return (p & PlatformFlags.AmazonFireTV) != 0;
                if(platform == Platforms.Platform.RazerForgeTV) return (p & PlatformFlags.RazerForgeTV) != 0;
                if(platform == Platforms.Platform.Windows81Store || platform == Platforms.Platform.WindowsAppStore) return (p & PlatformFlags.Windows8Store) != 0;
                if(platform == Platforms.Platform.WindowsUWP) return (p & PlatformFlags.WindowsUWP10) != 0;
                if(platform == Platforms.Platform.WebGL) return (p & PlatformFlags.WebGL) != 0;
                if(platform == Platforms.Platform.PS4) return (p & PlatformFlags.PS4) != 0;
                if(platform == Platforms.Platform.PSMobile || platform == Platforms.Platform.PSVita) return (p & PlatformFlags.PSVita) != 0;
                if(platform == Platforms.Platform.Xbox360) return (p & PlatformFlags.Xbox360) != 0;
                if(platform == Platforms.Platform.XboxOne) return (p & PlatformFlags.XboxOne) != 0;
                if(platform == Platforms.Platform.SamsungTV) return (p & PlatformFlags.SamsungTV) != 0;
                if(platform == Platforms.Platform.WiiU) return (p & PlatformFlags.WiiU) != 0;
                if(platform == Platforms.Platform.N3DS) return (p & PlatformFlags.Nintendo3DS) != 0;
                if(platform == Platforms.Platform.Switch) return (p & PlatformFlags.Switch) != 0;
                return (p & PlatformFlags.Unknown) != 0;
            }
        }

        private Dictionary<int, ActionMapping> actionMappingsDictionary {
            get { return _actionMappingsDictionary ?? (_actionMappingsDictionary = new Dictionary<int, ActionMapping>()); }
            set { _actionMappingsDictionary = value; }
        }

        protected override void Awake() {
            base.Awake();

            if(!Rewired.ReInput.isReady) {
                Debug.LogError(rewiredNotInitializedError);
                return;
            }

            // Check if a Rewired RexEngineInputManager already exists. If it does, do not replace it.
            // This is important for loading a scene additively and that contains another
            // Rewired Rex Engine Input Manager GameObject which will be automatically deleted.
            // This prevents setting it as the singleton instance on Awake by the loaded scene's component.
            if (global::RexEngine.InputManager.Instance as RexEngineInputManager != null) return;

            _initialized = true;

            // Initialize the Actions
            InitializeActionCache();

            // Set the singleton instance
            SetInstance(this);

            // Set this as the touch input manager
            touchInputManager = this;

            // Show/hide the touch UI initially
            bool showTouchControls = supportsTouchControls;
            _touchControlsActiveExternal = showTouchControls;
            SetTouchControlsActive(showTouchControls);

            if(_hideTouchControlsWhenJoysticksConnected) {
                _autoTouchControlUI_isActive = showTouchControls;
                CheckHideTouchControlsWhenJoystickConnected();
            }
        }

        protected override void OnEnable() {
            base.OnEnable();
            Rewired.ReInput.ControllerConnectedEvent += OnControllerConnected;
            Rewired.ReInput.ControllerDisconnectedEvent += OnControllerDisconnected;
        }

        protected override void OnDisable() {
            base.OnDisable();
            Rewired.ReInput.ControllerConnectedEvent -= OnControllerConnected;
            Rewired.ReInput.ControllerDisconnectedEvent -= OnControllerDisconnected;
        }

#if UNITY_EDITOR

        private void Reset() {
            actionMappings = new List<ActionMapping>() {
                new ActionMapping() { rewiredActionId = 2, rexEngineAction = global::RexEngine.InputAction.Jump },
                new ActionMapping() { rewiredActionId = 3, rexEngineAction = global::RexEngine.InputAction.Attack },
                new ActionMapping() { rewiredActionId = 4, rexEngineAction = global::RexEngine.InputAction.SubAttack },
                new ActionMapping() { rewiredActionId = 8, rexEngineAction = global::RexEngine.InputAction.SubAttack_2 },
                new ActionMapping() { rewiredActionId = 9, rexEngineAction = global::RexEngine.InputAction.SubAttack_3 },
                new ActionMapping() { rewiredActionId = 5, rexEngineAction = global::RexEngine.InputAction.Dash },
                new ActionMapping() { rewiredActionId = 6, rexEngineAction = global::RexEngine.InputAction.Run },
                new ActionMapping() { rewiredActionId = 0, rexEngineAction = global::RexEngine.InputAction.MoveHorizontal },
                new ActionMapping() { rewiredActionId = 1, rexEngineAction = global::RexEngine.InputAction.MoveVertical },
                new ActionMapping() { rewiredActionId = 7, rexEngineAction = global::RexEngine.InputAction.Pause },
                new ActionMapping() { rewiredActionId = 10, rexEngineAction = global::RexEngine.InputAction.Misc_1 },
                new ActionMapping() { rewiredActionId = 11, rexEngineAction = global::RexEngine.InputAction.Misc_2 },
            };
        }

#endif

        // Public methods

        public void ToggleTouchInterface(bool show) {
            showTouchControls = show;
        }

        public override bool GetButton(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return false;
            ActionMapping actionMapping = GetRewiredActionMapping(action);
            if (actionMapping == null) return false;
            return Rewired.ReInput.players.GetPlayer(playerId).GetButton(actionMapping.rewiredActionId);
        }

        public override bool GetButtonDown(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return false;
            ActionMapping actionMapping = GetRewiredActionMapping(action);
            if (actionMapping == null) return false;
            return Rewired.ReInput.players.GetPlayer(playerId).GetButtonDown(actionMapping.rewiredActionId);
        }

        public override bool GetButtonUp(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return false;
            ActionMapping actionMapping = GetRewiredActionMapping(action);
            if (actionMapping == null) return false;
            return Rewired.ReInput.players.GetPlayer(playerId).GetButtonUp(actionMapping.rewiredActionId);
        }

        public override float GetAxis(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return 0f;
            ActionMapping actionMapping = GetRewiredActionMapping(action);
            if (actionMapping == null) return 0f;
            return Rewired.ReInput.players.GetPlayer(playerId).GetAxis(actionMapping.rewiredActionId);
        }

        // Private methods

        private void InitializeActionCache() {
            actionMappingsDictionary.Clear();

            if (!ReInput.isReady) {
                Debug.LogError(rewiredNotInitializedError);
                return;
            }

            // Set up Actions
            int count = actionMappings != null ? actionMappings.Count : 0;
            for (int i = 0; i < count; i++) {
                if (!IsValidActionMapping(_actionMappings[i])) continue;
                if (actionMappingsDictionary.ContainsKey((int)_actionMappings[i].rexEngineAction)) {
                    Debug.LogWarning(scriptMessagePrefix + "Duplicate action found: " + _actionMappings[i].rexEngineAction + ". This is not allowed.");
                }
                actionMappingsDictionary.Add((int)actionMappings[i].rexEngineAction, actionMappings[i]);
            }
        }

        private void CheckHideTouchControlsWhenJoystickConnected() {
            if(!_hideTouchControlsWhenJoysticksConnected) return;

            if(_autoTouchControlUI_isActive) {
                // Disable touch controls if a joystick is connected
                if(Rewired.ReInput.controllers.joystickCount > 0) {
                    _autoTouchControlUI_isActive = false;
                }
            } else {
                // Enable touch controls if no joysticks are connected
                if(Rewired.ReInput.controllers.joystickCount == 0) {
                    _autoTouchControlUI_isActive = true;
                }
            }

            EvaluateTouchControlsActive();
        }

        private void EvaluateTouchControlsActive() {
            // Set the active state on the touch controls based on the external state and the auto state
            // Only set active if both external and internal are active
            SetTouchControlsActive(showTouchControls);
        }

        private void SetTouchControlsActive(bool active) {
            if(_touchControls == null) return;
            if(_touchControls.activeInHierarchy == active) return;
            _touchControls.SetActive(active);
        }

        private void OnControllerConnected(Rewired.ControllerStatusChangedEventArgs args) {
            if (args.controllerType != ControllerType.Joystick) return;
            CheckHideTouchControlsWhenJoystickConnected();
        }

        private void OnControllerDisconnected(Rewired.ControllerStatusChangedEventArgs args) {
            if (args.controllerType != ControllerType.Joystick) return;
            CheckHideTouchControlsWhenJoystickConnected();
        }

        private ActionMapping GetRewiredActionMapping(global::RexEngine.InputAction action) {
            ActionMapping actionMapping;
            if (!actionMappingsDictionary.TryGetValue((int)action, out actionMapping)) return null;
            return actionMapping;
        }

        private static bool IsValidActionMapping(ActionMapping mapping) {
            if (mapping == null) return false;
            if (mapping.rexEngineAction == global::RexEngine.InputAction.None) return false;
            Rewired.InputAction action = Rewired.ReInput.mapping.GetAction(mapping.rewiredActionId);
            return action != null;
        }

        private enum PlatformFlags {
            None = 0,
            Editor = 1,
            Windows = 1 << 1,
            OSX = 1 << 2,
            Linux = 1 << 3,
            IOS = 1 << 4,
            TVOS = 1 << 5,
            Android = 1 << 6,
            Windows8Store = 1 << 7,
            WindowsUWP10 = 1 << 8,
            WebGL = 1 << 9,
            PS4 = 1 << 10,
            PSVita = 1 << 11,
            Xbox360 = 1 << 12,
            XboxOne = 1 << 13,
            SamsungTV = 1 << 14,
            WiiU = 1 << 15,
            Nintendo3DS = 1 << 16,
            Switch = 1 << 17,
            AmazonFireTV = 1 << 18,
            RazerForgeTV = 1 << 19,
            Unknown = 1 << 31
        }

        [System.Serializable]
        public class ActionMapping {
            public global::RexEngine.InputAction rexEngineAction;
            public int rewiredActionId = -1;
        }
    }
}