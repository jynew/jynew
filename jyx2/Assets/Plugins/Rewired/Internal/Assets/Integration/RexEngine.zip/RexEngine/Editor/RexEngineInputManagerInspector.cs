﻿// Copyright (c) 2019 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

#pragma warning disable 0219
#pragma warning disable 0618
#pragma warning disable 0649
#pragma warning disable 0414
#pragma warning disable 0162

namespace Rewired.Integration.RexEngine.Editor {
    using System.Collections.Generic;
    using UnityEngine;
    using UnityEditor;

    [CustomEditor(typeof(RexEngineInputManager))]
    public sealed class RexEngineInputManagerInspector : UnityEditor.Editor {

        private const float columnSpace = 14f;

        private string[] _actionNames;
        private int[] _actionIds;
        private bool _initialized;
        private GUIStyle style_button;
        private GUIStyle style_columnHeading;
        private GUIStyle style_columnHeadingCentered;
        private GUIContent _heading_actionMappings = new GUIContent("Action Mappings");
        private GUIContent _heading_touchControls = new GUIContent("Touch Controls");
        private GUIContent _columnHeading_rexEngineAction = new GUIContent("Rex Engine Action", "The Rex Engine action name.");
        private GUIContent _columnHeading_rewiredAction = new GUIContent("Rewired Action", "The Rewired Action.");
        private GUIContent _columnHeading_delete = new GUIContent("Delete", "Delete the action mapping.");
        private Texture2D _icon_trash;

        private SerializedProperty sp_touchControls;
        private SerializedProperty sp_hideTouchControlsWhenJoysticksConnected;
        private SerializedProperty sp_showTouchControlsOn;

        private static int[] __rexInputValues;
        private static int[] rexInputValues {
            get {
                return __rexInputValues ?? (__rexInputValues = (int[])System.Enum.GetValues(typeof(global::RexEngine.InputAction)));
            }
        }
        private static string[] __rexInputNames;
        private static string[] rexInputNames {
            get {
                return __rexInputNames ?? (__rexInputNames = System.Enum.GetNames(typeof(global::RexEngine.InputAction)));
            }
        }

        private static Column[] columns = new Column[] {
            new Column() { width = 150, spaceAfter = columnSpace },
            new Column() { width = 150, spaceAfter = (int)(columnSpace / 2) },
            new Column() { width = 40 }
        };
        private static float allColumnsWidth {
            get {
                float width = 0;
                for (int i = 0; i < columns.Length; i++) {
                    width += columns[i].width + columns[i].spaceAfter;
                }
                return width;
            }
        }

        private void OnEnable() {

            sp_touchControls = serializedObject.FindProperty("_touchControls");
            sp_hideTouchControlsWhenJoysticksConnected = serializedObject.FindProperty("_hideTouchControlsWhenJoysticksConnected");
            sp_showTouchControlsOn = serializedObject.FindProperty("_showTouchControlsOn");

            InputManager rim = (target as Behaviour).GetComponent<InputManager>();

            // Get all Rewired actions sorted by category
            int[] actionCatIds = rim.userData.GetActionCategoryIds();
            int[] allActionIds = rim.userData.GetActionIds();
            List<string> names = new List<string>();
            List<int> ids = new List<int>();

            foreach (int catId in actionCatIds) {
                foreach (int id in allActionIds) {
                    InputAction action = rim.userData.GetActionById(id);
                    if (action.categoryId != catId) continue;
                    names.Add(action.name);
                    ids.Add(id);
                }
            }

            names.Insert(0, "None");
            ids.Insert(0, -1);
            this._actionNames = names.ToArray();
            this._actionIds = ids.ToArray();

            // Load editor icons
            _icon_trash = EditorGUIUtility.Load("icons/TreeEditor.Trash.png") as Texture2D;
            _icon_trash.hideFlags = HideFlags.HideAndDontSave;
        }

        public override void OnInspectorGUI() {
            if (!_initialized) Initialize();

            EditorGUILayout.Space();

            serializedObject.Update();

            DrawActionMappings();
            GUILayout.Space(15f);

            EditorGUILayout.LabelField(_heading_touchControls, EditorStyles.boldLabel);
            GUILayout.Space(5f);
            EditorGUILayout.PropertyField(sp_touchControls);
            EditorGUILayout.PropertyField(sp_hideTouchControlsWhenJoysticksConnected);
            GUILayout.Space(5f);
            EditorGUILayout.PropertyField(sp_showTouchControlsOn);
            GUILayout.Space(15f);

            serializedObject.ApplyModifiedProperties();
        }

        private void DrawActionMappings() {

            EditorGUILayout.LabelField(_heading_actionMappings, EditorStyles.boldLabel);
            GUILayout.Space(5f);
            EditorGUILayout.HelpBox("Each Rex Engine action must be mapped to a Rewired Action. When Rex Engine gets input, " +
                "the Rex Engine action will be used to look up a Rewired Action. The name of the Rewired Action can be different from the Rex Engine name.",
                MessageType.Info
            );
            GUILayout.Space(10f);

            RexEngineInputManager target = this.target as RexEngineInputManager;

            var actionMappings = target.actionMappings;
            int arrayLength = actionMappings != null ? actionMappings.Count : 0;

            if (arrayLength > 0) {

                int removeAtIndex = -1;
                int colIndex = 0;

                GUILayout.BeginHorizontal();
                {
                    float fieldHeight = GUI.skin.button.CalcHeight(new GUIContent("-"), 50f);
                    float rowSpace = 3f;

                    // Rex Engine Action
                    GUILayout.BeginVertical(GUILayout.Width(columns[colIndex].width));
                    {
                        GUILayout.Label(_columnHeading_rexEngineAction, style_columnHeading);
                        GUILayout.Space(5f);
                        for (int i = 0; i < arrayLength; i++) {
                            RexEngineInputManager.ActionMapping item = actionMappings[i];
                            if (item != null) {
                                global::RexEngine.InputAction rexAction;
                                EditorGUI.BeginChangeCheck();
                                {
                                    rexAction = (global::RexEngine.InputAction)EditorGUILayout.IntPopup((int)item.rexEngineAction, rexInputNames, rexInputValues, GUILayout.Height(fieldHeight));
                                }
                                if (EditorGUI.EndChangeCheck()) {
                                    Undo.RecordObject(target, "Change Action Mapping");
                                    item.rexEngineAction = rexAction;
                                    EditorUtility.SetDirty(target);  // docs say not to do this in 5.3+ for scene objects, but undo on prefabs is bugged if we don't
                                }
                            } else {
                                EditorGUILayout.LabelField("NULL");
                            }
                            GUILayout.Space(rowSpace);
                        }

                        GUILayout.EndVertical();
                        if (columns[colIndex].spaceAfter > 0f) GUILayout.Space(columns[colIndex].spaceAfter);
                        colIndex++;

                        // Rewired Action
                        GUILayout.BeginVertical(GUILayout.Width(columns[colIndex].width));
                        {
                            GUILayout.Label(_columnHeading_rewiredAction, style_columnHeading);
                            GUILayout.Space(5f);

                            for (int i = 0; i < arrayLength; i++) {
                                RexEngineInputManager.ActionMapping item = actionMappings[i];
                                if (item != null) {
                                    EditorGUI.BeginChangeCheck();
                                    int rewiredActionId = EditorGUILayout.IntPopup("", item.rewiredActionId, _actionNames, _actionIds, GUILayout.Height(fieldHeight), GUILayout.Width(columns[colIndex].width));
                                    if (EditorGUI.EndChangeCheck()) {
                                        Undo.RecordObject(target, "Change Action Mapping");
                                        item.rewiredActionId = rewiredActionId;
                                        EditorUtility.SetDirty(target);
                                    }
                                } else {
                                    EditorGUILayout.LabelField("NULL");
                                }
                                GUILayout.Space(rowSpace);
                            }
                        }
                        GUILayout.EndVertical();
                        if (columns[colIndex].spaceAfter > 0f) GUILayout.Space(columns[colIndex].spaceAfter);
                        colIndex++;

                        // Delete
                        GUILayout.BeginVertical(GUILayout.Width(columns[colIndex].width));
                        {
                            GUILayout.Label(_columnHeading_delete, style_columnHeadingCentered);
                            GUILayout.Space(5f);

                            for (int i = 0; i < arrayLength; i++) {
                                GUILayout.BeginHorizontal();
                                {
                                    GUILayout.FlexibleSpace();
                                    if (GUILayout.Button(_icon_trash, style_button, GUILayout.Height(fieldHeight))) removeAtIndex = i;
                                    GUILayout.FlexibleSpace();
                                }
                                GUILayout.EndHorizontal();
                                GUILayout.Space(rowSpace);
                            }
                        }
                        GUILayout.EndVertical();
                        if (columns[colIndex].spaceAfter > 0f) GUILayout.Space(columns[colIndex].spaceAfter);
                        colIndex++;
                    }
                }
                GUILayout.EndHorizontal();

                if (removeAtIndex >= 0) {
                    Undo.RecordObject(target, "Remove Action Mapping");
                    actionMappings.RemoveAt(removeAtIndex);
                    EditorUtility.SetDirty(target);
                }
            }

            if (GUILayout.Button("+ Add Action Mapping", GUILayout.Width(allColumnsWidth + 13f))) {
                Undo.RecordObject(target, "Add Action Mapping");
                if (actionMappings == null) {
                    actionMappings = new List<RexEngineInputManager.ActionMapping>();
                    target.actionMappings = actionMappings;
                }
                actionMappings.Add(new RexEngineInputManager.ActionMapping());
                EditorUtility.SetDirty(target);
            }
        }

        private void Initialize() {
            style_button = new GUIStyle(GUI.skin.button);
            style_button.margin = new RectOffset(0, 0, 2, 2);
            style_button.padding = new RectOffset(6, 6, 0, 0);
            style_columnHeading = new GUIStyle(EditorStyles.label);
            style_columnHeadingCentered = new GUIStyle(EditorStyles.label);
            style_columnHeadingCentered.alignment = TextAnchor.MiddleCenter;
            _initialized = true;
        }

        private class Column {
            public float width;
            public float spaceAfter;
        }
    }
}